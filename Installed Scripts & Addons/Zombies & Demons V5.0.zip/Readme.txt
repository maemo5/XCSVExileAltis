Zombies & Demons Readme File
Version 5.0
by Ryan and MrSanchez


This mod includes place and play zombies & demons with custom animations and unique customisable options. They can be found in mission editor and will attack any enemies they know about based on the side they're on (Opfor zombies will attack Blufor units).

Zombie stength and abilities can be easily customised. These features are off by default and are only enabled if the appropriate module is placed.
- Allow zombies to throw cars, leap into the air, feed on dead bodies, and more!
- Heavily customisable spawners with max alive limits, spawn animations, and much more!
- Adjust zombies max health, attack strength, and other settings.

I am continuing with the development of this mod with plans for new features, more gore, bug fixes, and any suggestions.

If you want to send a donation, my paypal is:
ryandombrowsky@gmail.com
It would be very much appreciated!

Thank you and enjoy the mod!


Zombies & Demons Disclaimer:

- Using content of the Z&D modification and publicly redistributing it as part of a different modification is not allowed unless permission is given by official Z&D developers.
- Redistributing a modified version of the Z&D mod is not allowed unless permission is given by official Z&D developers.
- Using content of the Z&D modification on monetized servers is prohibited unless permission is given by official Z&D developers. 

- The permissions above can be given on a case by case basis and the reasons to give permission may vary per request.