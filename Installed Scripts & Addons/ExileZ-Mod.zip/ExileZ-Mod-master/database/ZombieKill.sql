/*
 *
 * Add the zedkills field
 *
*/

ALTER TABLE account ADD zedkills int(11) DEFAULT '0'