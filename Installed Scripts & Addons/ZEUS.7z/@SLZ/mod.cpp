name = "seelenlos Zeus 1.7";
picture = "slz.paa";
tooltip = "seelenlos Zeus";
overview = "This mod creates a zeus and assign the player if he is whitelisted!";
author = "seelenlos";
logoOver = "slz.paa";